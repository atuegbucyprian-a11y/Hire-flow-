# HireFlow 🚀

**AI-powered job hunting platform for remote, hybrid, and freelance roles — worldwide.**

HireFlow helps job seekers find the right opportunities faster. Upload your CV, let AI parse your skills and experience, get instant match scores on job listings, and track every application — all in one clean interface.

---

## ✨ Features

- **Registration & onboarding** — name, email, role, experience level
- **AI CV parsing** — upload a PDF/DOCX/TXT and Claude extracts your skills, strengths, and summary instantly
- **Smart job matching** — every listing gets a % match score based on your profile
- **Global job listings** — Remote (Worldwide), Hybrid, and Freelance/Contract roles with no region lock
- **Filters** — by job type, category (Engineering, Design, Marketing, Data, etc.), and experience level
- **One-click apply** — apply directly and it's logged automatically
- **Application tracker** — status pipeline: Applied → Reviewing → Interview → Offer/Rejected
- **AI Career Assistant** — Claude-powered chat sidebar for job search advice, CV tips, and interview prep

---

## 🛠 Tech Stack

| Layer | Tech |
|---|---|
| Framework | React 18 + Vite |
| Styling | Inline CSS + CSS variables (no extra library needed) |
| Fonts | DM Serif Display + DM Sans (Google Fonts) |
| AI | Anthropic Claude (`claude-sonnet-4-20250514`) |
| State | React `useState` / `useRef` / `useEffect` |

---

## 🚀 Getting Started

### 1. Clone the repo

```bash
git clone https://github.com/YOUR_USERNAME/hireflow.git
cd hireflow
```

### 2. Install dependencies

```bash
npm install
```

### 3. Set up your Anthropic API key

```bash
cp .env.example .env
```

Then open `.env` and add your key:

```
VITE_ANTHROPIC_API_KEY=sk-ant-...
```

Get your API key at [console.anthropic.com](https://console.anthropic.com).

> ⚠️ **Note:** For production, never expose your Anthropic API key on the frontend. Move AI calls to a backend (Node.js/Express, Next.js API routes, etc.) and call from there.

### 4. Run the dev server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

---

## 📁 Project Structure

```
hireflow/
├── index.html
├── vite.config.js
├── package.json
├── .env.example
├── .gitignore
└── src/
    ├── main.jsx       # React entry point
    └── App.jsx        # Full application (single-file)
```

---

## 🗺 Roadmap

- [ ] Real job board API integration (Remotive, Adzuna, LinkedIn)
- [ ] Auth backend (Supabase or Firebase)
- [ ] Move AI calls to server-side (Next.js API routes)
- [ ] Resume builder with per-job tailoring
- [ ] Email/push notifications for application status updates
- [ ] Saved job collections
- [ ] Company profiles and reviews
- [ ] Browser extension for one-click apply on external job boards

---

## 🤝 Contributing

PRs welcome. Open an issue first for major changes.

---

## 📄 License

MIT
