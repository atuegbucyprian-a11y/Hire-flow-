import { useState, useRef, useEffect } from "react";

const TABS = ["Dashboard", "Find Jobs", "My Applications", "Profile"];

const JOB_TYPES = ["All", "Remote", "Hybrid", "On-site", "Freelance/Contract"];
const CATEGORIES = ["All", "Engineering", "Design", "Marketing", "Finance", "Product", "Data", "Operations"];
const EXPERIENCE = ["All", "Entry Level", "Mid Level", "Senior", "Lead/Manager"];

const MOCK_JOBS = [
  { id: 1, title: "Senior Frontend Engineer", company: "Linear", location: "Remote — Worldwide", type: "Remote", category: "Engineering", salary: "$130k–$170k", logo: "L", color: "#5E6AD2", match: 97, posted: "2d ago", description: "Build beautiful, fast interfaces for our product used by thousands of engineering teams.", tags: ["React", "TypeScript", "CSS"] },
  { id: 2, title: "Product Designer", company: "Vercel", location: "Remote — Worldwide", type: "Remote", category: "Design", salary: "$110k–$145k", logo: "V", color: "#000000", match: 91, posted: "1d ago", description: "Shape the future of web development tooling through thoughtful, user-centered design.", tags: ["Figma", "Product Thinking", "UI/UX"] },
  { id: 3, title: "Growth Marketing Lead", company: "Notion", location: "Remote — Worldwide", type: "Remote", category: "Marketing", salary: "$120k–$155k", logo: "N", color: "#191919", match: 84, posted: "3d ago", description: "Drive user acquisition and retention strategies for Notion's growing customer base.", tags: ["SEO", "Paid Ads", "Analytics"] },
  { id: 4, title: "Data Engineer", company: "Stripe", location: "Remote — Worldwide", type: "Remote", category: "Data", salary: "$140k–$180k", logo: "S", color: "#635BFF", match: 88, posted: "5h ago", description: "Build and maintain data pipelines that power Stripe's core analytics platform.", tags: ["Python", "dbt", "Snowflake"] },
  { id: 5, title: "Full Stack Developer", company: "Shopify", location: "Remote — Worldwide", type: "Remote", category: "Engineering", salary: "$120k–$160k", logo: "S", color: "#96BF48", match: 93, posted: "1d ago", description: "Build merchant-facing features across Shopify's commerce platform.", tags: ["Ruby", "React", "GraphQL"] },
  { id: 6, title: "UX Researcher", company: "Figma", location: "Remote — Worldwide", type: "Remote", category: "Design", salary: "$115k–$145k", logo: "F", color: "#F24E1E", match: 79, posted: "4d ago", description: "Conduct user research to inform product decisions across Figma's design suite.", tags: ["User Interviews", "Surveys", "Synthesis"] },
  { id: 7, title: "iOS Developer", company: "Superhuman", location: "Remote — Worldwide", type: "Remote", category: "Engineering", salary: "$130k–$165k", logo: "S", color: "#FF3A3A", match: 82, posted: "2d ago", description: "Build the fastest email experience ever made for iOS.", tags: ["Swift", "SwiftUI", "Performance"] },
  { id: 8, title: "Finance Manager", company: "Brex", location: "Remote — Worldwide", type: "Remote", category: "Finance", salary: "$125k–$155k", logo: "B", color: "#FF5C35", match: 76, posted: "6d ago", description: "Own financial planning and analysis for Brex's fintech products.", tags: ["FP&A", "Excel", "SQL"] },
  { id: 9, title: "Contract: Brand Designer", company: "Loom", location: "Remote — Worldwide", type: "Freelance/Contract", category: "Design", salary: "$80–$120/hr", logo: "L", color: "#625DF5", match: 88, posted: "1d ago", description: "6-month contract to refresh Loom's visual brand identity across all touchpoints.", tags: ["Branding", "Illustration", "Motion"] },
  { id: 10, title: "Backend Engineer", company: "Supabase", location: "Remote — Worldwide", type: "Remote", category: "Engineering", salary: "$120k–$160k", logo: "S", color: "#3ECF8E", match: 90, posted: "3h ago", description: "Work on the open source Firebase alternative powering hundreds of thousands of developers globally.", tags: ["PostgreSQL", "Go", "Elixir"] },
  { id: 11, title: "DevOps Engineer", company: "Cloudflare", location: "Remote — Worldwide", type: "Remote", category: "Engineering", salary: "$125k–$165k", logo: "C", color: "#F6821F", match: 85, posted: "1d ago", description: "Help build and maintain the infrastructure that powers Cloudflare's global network.", tags: ["Kubernetes", "Terraform", "CI/CD"] },
  { id: 12, title: "Contract: React Native Dev", company: "Pitch", location: "Remote — Worldwide", type: "Freelance/Contract", category: "Engineering", salary: "$70–$110/hr", logo: "P", color: "#7C3AED", match: 87, posted: "2d ago", description: "3-month contract to build mobile companion app for Pitch's collaborative presentation platform.", tags: ["React Native", "TypeScript", "Mobile"] },
  { id: 13, title: "Content Strategist", company: "Buffer", location: "Remote — Worldwide", type: "Remote", category: "Marketing", salary: "$80k–$110k", logo: "B", color: "#2C4BFF", match: 80, posted: "4d ago", description: "Own Buffer's content strategy and editorial calendar to grow organic reach worldwide.", tags: ["Content", "SEO", "Writing"] },
  { id: 14, title: "ML Engineer", company: "Hugging Face", location: "Remote — Worldwide", type: "Remote", category: "Data", salary: "$145k–$185k", logo: "H", color: "#FFD21E", match: 83, posted: "6h ago", description: "Work at the frontier of open-source AI, building tools and models used by millions of researchers.", tags: ["Python", "PyTorch", "Transformers"] },
  { id: 15, title: "Operations Manager", company: "Remote.com", location: "Remote — Worldwide", type: "Remote", category: "Operations", salary: "$95k–$125k", logo: "R", color: "#0F172A", match: 77, posted: "5d ago", description: "Lead operational excellence across Remote's global employment platform serving 180+ countries.", tags: ["Ops", "Process", "Scaling"] },
  { id: 16, title: "Product Manager", company: "Miro", location: "Remote — Worldwide", type: "Remote", category: "Product", salary: "$130k–$165k", logo: "M", color: "#FFDE00", match: 86, posted: "2d ago", description: "Drive product strategy for Miro's collaborative whiteboard platform used by 60M+ users.", tags: ["Roadmap", "Discovery", "Agile"] },
  { id: 17, title: "Hybrid: UX Lead", company: "Zalando", location: "Hybrid — Berlin, Germany", type: "Hybrid", category: "Design", salary: "€90k–€120k", logo: "Z", color: "#FF6900", match: 81, posted: "3d ago", description: "Lead a team of designers shaping the experience for Europe's largest fashion platform.", tags: ["Leadership", "Design Systems", "Research"] },
  { id: 18, title: "Hybrid: Data Analyst", company: "Spotify", location: "Hybrid — Stockholm, Sweden", type: "Hybrid", category: "Data", salary: "€75k–€100k", logo: "S", color: "#1DB954", match: 78, posted: "4d ago", description: "Uncover insights from Spotify's music and podcast data to shape product decisions.", tags: ["SQL", "Python", "Looker"] },
];

const MOCK_APPLICATIONS = [
  { id: 1, title: "Senior Frontend Engineer", company: "Linear", status: "Interview", date: "Jun 1", logo: "L", color: "#5E6AD2", next: "Technical interview Jun 8" },
  { id: 2, title: "Full Stack Developer", company: "Shopify", status: "Applied", date: "Jun 3", logo: "S", color: "#96BF48", next: "Awaiting response" },
  { id: 3, title: "Data Engineer", company: "Stripe", status: "Reviewing", date: "May 28", logo: "S", color: "#635BFF", next: "Recruiter screen scheduled" },
  { id: 4, title: "Product Designer", company: "Figma", status: "Rejected", date: "May 20", logo: "F", color: "#F24E1E", next: "—" },
];

const STATUS_COLORS = {
  Applied: { bg: "#EEF2FF", text: "#4338CA" },
  Reviewing: { bg: "#FFF7ED", text: "#C2410C" },
  Interview: { bg: "#F0FDF4", text: "#15803D" },
  Rejected: { bg: "#FEF2F2", text: "#B91C1C" },
  Offer: { bg: "#F0FDF4", text: "#15803D" },
};

function Spinner() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{ width: 16, height: 16, border: "2px solid #E5E7EB", borderTop: "2px solid #111827", borderRadius: "50%", animation: "spin 0.7s linear infinite" }} />
    </div>
  );
}

function AIChat({ cvParsed, profile }) {
  const [messages, setMessages] = useState([
    { role: "assistant", content: `Hi! I'm your job search assistant. ${cvParsed ? "I've analyzed your CV and I'm ready to help you find the perfect role." : "Upload your CV so I can give you personalized job recommendations."} What are you looking for today?` }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMsg }]);
    setLoading(true);

    try {
      const systemPrompt = `You are a smart, friendly job search assistant for a platform called HireFlow. 
You help job hunters find remote, hybrid, and contract/freelance jobs.
${cvParsed ? `The user has uploaded their CV. Parsed info: ${JSON.stringify(cvParsed)}` : "The user hasn't uploaded a CV yet."}
${profile?.name ? `User name: ${profile.name}` : ""}
Keep replies concise (2–4 sentences). Be actionable and encouraging. If asked about specific jobs, refer to companies like Linear, Vercel, Stripe, Shopify, Figma, Notion. Always stay focused on job searching, career advice, CV tips, and interview prep.`;

      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: systemPrompt,
          messages: [...messages, { role: "user", content: userMsg }].map(m => ({ role: m.role, content: m.content }))
        })
      });
      const data = await resp.json();
      const text = data.content?.map(b => b.text || "").join("") || "Sorry, I couldn't respond right now.";
      setMessages(prev => [...prev, { role: "assistant", content: text }]);
    } catch {
      setMessages(prev => [...prev, { role: "assistant", content: "Something went wrong. Please try again." }]);
    }
    setLoading(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#FAFAFA", borderRadius: 16, border: "1px solid #E5E7EB", overflow: "hidden" }}>
      <div style={{ padding: "16px 20px", borderBottom: "1px solid #E5E7EB", background: "#fff", display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, #111827, #374151)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ color: "#fff", fontSize: 14 }}>✦</span>
        </div>
        <div>
          <div style={{ fontWeight: 600, fontSize: 14, color: "#111827" }}>AI Career Assistant</div>
          <div style={{ fontSize: 11, color: "#6B7280" }}>Powered by Claude</div>
        </div>
        <div style={{ marginLeft: "auto", width: 8, height: 8, borderRadius: "50%", background: "#22C55E" }} />
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            <div style={{
              maxWidth: "80%", padding: "10px 14px", borderRadius: m.role === "user" ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
              background: m.role === "user" ? "#111827" : "#fff",
              color: m.role === "user" ? "#fff" : "#374151",
              fontSize: 13.5, lineHeight: 1.6,
              border: m.role === "assistant" ? "1px solid #E5E7EB" : "none",
              boxShadow: "0 1px 3px rgba(0,0,0,0.06)"
            }}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex", justifyContent: "flex-start" }}>
            <div style={{ padding: "10px 14px", borderRadius: "16px 16px 16px 4px", background: "#fff", border: "1px solid #E5E7EB" }}>
              <Spinner />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div style={{ padding: "12px 16px", borderTop: "1px solid #E5E7EB", background: "#fff", display: "flex", gap: 8 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && send()}
          placeholder="Ask about jobs, CV tips, interview prep…"
          style={{ flex: 1, border: "1px solid #E5E7EB", borderRadius: 10, padding: "10px 14px", fontSize: 13.5, outline: "none", background: "#FAFAFA", color: "#111827" }}
        />
        <button onClick={send} disabled={loading || !input.trim()} style={{
          background: "#111827", color: "#fff", border: "none", borderRadius: 10, padding: "10px 16px", cursor: "pointer", fontSize: 14, opacity: (!input.trim() || loading) ? 0.4 : 1, transition: "opacity 0.2s"
        }}>↑</button>
      </div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState("landing"); // landing | register | app
  const [activeTab, setActiveTab] = useState("Dashboard");
  const [authMode, setAuthMode] = useState("register");
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "", experience: "" });
  const [profile, setProfile] = useState(null);
  const [cvFile, setCvFile] = useState(null);
  const [cvParsed, setCvParsed] = useState(null);
  const [cvLoading, setCvLoading] = useState(false);
  const [jobType, setJobType] = useState("All");
  const [jobCategory, setJobCategory] = useState("All");
  const [jobExp, setJobExp] = useState("All");
  const [search, setSearch] = useState("");
  const [savedJobs, setSavedJobs] = useState([1, 5]);
  const [applications, setApplications] = useState(MOCK_APPLICATIONS);
  const [appliedNow, setAppliedNow] = useState([]);
  const fileRef = useRef();

  const filteredJobs = MOCK_JOBS.filter(j => {
    const matchType = jobType === "All" || j.type === jobType;
    const matchCat = jobCategory === "All" || j.category === jobCategory;
    const matchSearch = !search || j.title.toLowerCase().includes(search.toLowerCase()) || j.company.toLowerCase().includes(search.toLowerCase()) || j.tags.some(t => t.toLowerCase().includes(search.toLowerCase()));
    return matchType && matchCat && matchSearch;
  }).sort((a, b) => b.match - a.match);

  const handleRegister = () => {
    if (!form.name || !form.email) return;
    setProfile(form);
    setScreen("app");
  };

  const parseCV = async (file) => {
    setCvLoading(true);
    try {
      const text = await file.text().catch(() => `CV file: ${file.name}`);
      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: "You are a CV parser. Extract key info from the CV text and return ONLY a JSON object with these fields: name, title, skills (array, max 8), experience (years as number), topStrengths (array of 3 short strings), summary (1 sentence). No markdown, no explanation.",
          messages: [{ role: "user", content: `Parse this CV: ${text.slice(0, 3000)}` }]
        })
      });
      const data = await resp.json();
      const raw = data.content?.map(b => b.text || "").join("") || "{}";
      const clean = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setCvParsed(parsed);
    } catch {
      setCvParsed({ name: profile?.name, title: "Professional", skills: ["Communication", "Problem Solving", "Teamwork"], experience: 3, topStrengths: ["Fast learner", "Detail-oriented", "Collaborative"], summary: "Experienced professional seeking new opportunities." });
    }
    setCvLoading(false);
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) { setCvFile(file); parseCV(file); }
  };

  const handleApply = (job) => {
    setAppliedNow(prev => [...prev, job.id]);
    setApplications(prev => [{ id: job.id + 100, title: job.title, company: job.company, status: "Applied", date: "Jun 4", logo: job.logo, color: job.color, next: "Awaiting response" }, ...prev]);
  };

  // LANDING
  if (screen === "landing") return (
    <div style={{ minHeight: "100vh", background: "#fff", fontFamily: "'Georgia', 'Times New Roman', serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'DM Sans', sans-serif; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
        .fade-up { animation: fadeUp 0.6s ease forwards; }
        .fade-up-2 { animation: fadeUp 0.6s 0.15s ease both; }
        .fade-up-3 { animation: fadeUp 0.6s 0.3s ease both; }
        .btn-primary:hover { background: #374151 !important; }
        .btn-outline:hover { background: #F9FAFB !important; }
        .job-card:hover { border-color: #9CA3AF !important; box-shadow: 0 4px 20px rgba(0,0,0,0.08) !important; }
      `}</style>

      <nav style={{ padding: "20px 48px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #F3F4F6" }}>
        <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 22, color: "#111827", letterSpacing: "-0.5px" }}>HireFlow</div>
        <div style={{ display: "flex", gap: 12 }}>
          <button className="btn-outline" onClick={() => { setAuthMode("login"); setScreen("register"); }} style={{ padding: "9px 20px", borderRadius: 8, border: "1px solid #E5E7EB", background: "#fff", cursor: "pointer", fontSize: 14, color: "#374151", fontFamily: "'DM Sans', sans-serif", transition: "background 0.2s" }}>Sign in</button>
          <button className="btn-primary" onClick={() => { setAuthMode("register"); setScreen("register"); }} style={{ padding: "9px 20px", borderRadius: 8, border: "none", background: "#111827", cursor: "pointer", fontSize: 14, color: "#fff", fontFamily: "'DM Sans', sans-serif", transition: "background 0.2s" }}>Get started</button>
        </div>
      </nav>

      <div style={{ maxWidth: 960, margin: "0 auto", padding: "80px 48px 60px" }}>
        <div className="fade-up" style={{ textAlign: "center" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#F3F4F6", borderRadius: 100, padding: "6px 14px", marginBottom: 28, fontSize: 12.5, color: "#6B7280", fontFamily: "'DM Sans', sans-serif" }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#22C55E", display: "inline-block" }} /> AI-powered job search · Remote, Hybrid & Contract
          </div>
          <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 64, lineHeight: 1.1, color: "#111827", letterSpacing: "-2px", marginBottom: 20 }}>
            Find work that<br /><span style={{ fontStyle: "italic", color: "#6B7280" }}>fits your life.</span>
          </h1>
          <p className="fade-up-2" style={{ fontSize: 18, color: "#6B7280", lineHeight: 1.7, maxWidth: 480, margin: "0 auto 40px", fontFamily: "'DM Sans', sans-serif", fontWeight: 300 }}>
            Upload your CV and let AI match you to remote, hybrid, and freelance roles — then track every application in one place.
          </p>
          <div className="fade-up-3" style={{ display: "flex", gap: 12, justifyContent: "center" }}>
            <button className="btn-primary" onClick={() => setScreen("register")} style={{ padding: "14px 32px", borderRadius: 10, border: "none", background: "#111827", cursor: "pointer", fontSize: 15, color: "#fff", fontFamily: "'DM Sans', sans-serif", fontWeight: 500, transition: "background 0.2s" }}>Start for free</button>
            <button className="btn-outline" onClick={() => setScreen("register")} style={{ padding: "14px 32px", borderRadius: 10, border: "1px solid #E5E7EB", background: "#fff", cursor: "pointer", fontSize: 15, color: "#374151", fontFamily: "'DM Sans', sans-serif", transition: "background 0.2s" }}>See how it works</button>
          </div>
        </div>

        <div style={{ marginTop: 80, display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24 }}>
          {[
            { icon: "⚡", title: "AI CV Parsing", desc: "Upload once. Our AI extracts your skills, experience and strengths to match you instantly." },
            { icon: "🎯", title: "Smart Matching", desc: "See a match score for every job. Know immediately if a role fits before you apply." },
            { icon: "📋", title: "Application Tracker", desc: "Track every application — from sent to offer — without a spreadsheet." }
          ].map((f, i) => (
            <div key={i} style={{ padding: 28, border: "1px solid #E5E7EB", borderRadius: 16, background: "#FAFAFA" }}>
              <div style={{ fontSize: 24, marginBottom: 12 }}>{f.icon}</div>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 18, color: "#111827", marginBottom: 8 }}>{f.title}</div>
              <div style={{ fontSize: 14, color: "#6B7280", lineHeight: 1.6, fontFamily: "'DM Sans', sans-serif" }}>{f.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // REGISTER / LOGIN
  if (screen === "register") return (
    <div style={{ minHeight: "100vh", background: "#fff", display: "flex", fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap'); * { box-sizing: border-box; } @keyframes fadeUp { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } } .auth-form { animation: fadeUp 0.5s ease; } input:focus { border-color: #111827 !important; outline: none; } .btn-primary:hover { background: #374151 !important; }`}</style>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", padding: 48 }}>
        <div className="auth-form" style={{ width: "100%", maxWidth: 420 }}>
          <div onClick={() => setScreen("landing")} style={{ fontFamily: "'DM Serif Display', serif", fontSize: 20, color: "#111827", marginBottom: 40, cursor: "pointer" }}>← HireFlow</div>

          <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 32, color: "#111827", marginBottom: 6, letterSpacing: "-0.5px" }}>
            {authMode === "register" ? "Create your account" : "Welcome back"}
          </h2>
          <p style={{ color: "#9CA3AF", fontSize: 14, marginBottom: 32 }}>
            {authMode === "register" ? "Start finding jobs that fit your life." : "Sign in to continue your job search."}
          </p>

          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {authMode === "register" && (
              <div>
                <label style={{ fontSize: 13, color: "#374151", fontWeight: 500, marginBottom: 6, display: "block" }}>Full name</label>
                <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Alex Johnson" style={{ width: "100%", padding: "11px 14px", border: "1px solid #E5E7EB", borderRadius: 9, fontSize: 14, color: "#111827", transition: "border-color 0.2s", background: "#fff" }} />
              </div>
            )}
            <div>
              <label style={{ fontSize: 13, color: "#374151", fontWeight: 500, marginBottom: 6, display: "block" }}>Email</label>
              <input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="alex@email.com" type="email" style={{ width: "100%", padding: "11px 14px", border: "1px solid #E5E7EB", borderRadius: 9, fontSize: 14, color: "#111827", transition: "border-color 0.2s", background: "#fff" }} />
            </div>
            <div>
              <label style={{ fontSize: 13, color: "#374151", fontWeight: 500, marginBottom: 6, display: "block" }}>Password</label>
              <input value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="••••••••" type="password" style={{ width: "100%", padding: "11px 14px", border: "1px solid #E5E7EB", borderRadius: 9, fontSize: 14, color: "#111827", transition: "border-color 0.2s", background: "#fff" }} />
            </div>
            {authMode === "register" && (
              <>
                <div>
                  <label style={{ fontSize: 13, color: "#374151", fontWeight: 500, marginBottom: 6, display: "block" }}>Job title / role</label>
                  <input value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} placeholder="e.g. Frontend Engineer, Product Designer" style={{ width: "100%", padding: "11px 14px", border: "1px solid #E5E7EB", borderRadius: 9, fontSize: 14, color: "#111827", transition: "border-color 0.2s", background: "#fff" }} />
                </div>
                <div>
                  <label style={{ fontSize: 13, color: "#374151", fontWeight: 500, marginBottom: 6, display: "block" }}>Experience level</label>
                  <select value={form.experience} onChange={e => setForm({ ...form, experience: e.target.value })} style={{ width: "100%", padding: "11px 14px", border: "1px solid #E5E7EB", borderRadius: 9, fontSize: 14, color: "#111827", background: "#fff", appearance: "none" }}>
                    <option value="">Select level</option>
                    <option>Entry Level (0–2 yrs)</option><option>Mid Level (3–5 yrs)</option><option>Senior (6–9 yrs)</option><option>Lead / Manager (10+ yrs)</option>
                  </select>
                </div>
              </>
            )}
          </div>

          <button className="btn-primary" onClick={handleRegister} style={{ width: "100%", marginTop: 24, padding: "13px", borderRadius: 10, border: "none", background: "#111827", color: "#fff", fontSize: 15, fontWeight: 500, cursor: "pointer", fontFamily: "'DM Sans', sans-serif", transition: "background 0.2s" }}>
            {authMode === "register" ? "Create account" : "Sign in"}
          </button>

          <p style={{ textAlign: "center", marginTop: 20, fontSize: 13.5, color: "#9CA3AF" }}>
            {authMode === "register" ? "Already have an account? " : "Don't have an account? "}
            <span onClick={() => setAuthMode(authMode === "register" ? "login" : "register")} style={{ color: "#111827", fontWeight: 500, cursor: "pointer" }}>
              {authMode === "register" ? "Sign in" : "Create one"}
            </span>
          </p>
        </div>
      </div>

      <div style={{ width: 480, background: "#111827", display: "flex", flexDirection: "column", justifyContent: "center", padding: 56 }}>
        <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 36, color: "#fff", lineHeight: 1.2, marginBottom: 24, letterSpacing: "-1px" }}>
          Your next role<br /><span style={{ fontStyle: "italic", color: "#9CA3AF" }}>is one upload away.</span>
        </div>
        <p style={{ color: "#6B7280", fontSize: 15, lineHeight: 1.7, marginBottom: 40 }}>HireFlow uses AI to match your skills and experience to the best remote, hybrid, and freelance opportunities worldwide.</p>
        {[
          "AI parses your CV in seconds",
          "Match scores for every job listing",
          "Track applications without spreadsheets",
          "Chat with your AI career assistant"
        ].map((f, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
            <div style={{ width: 20, height: 20, borderRadius: "50%", background: "#374151", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <span style={{ color: "#9CA3AF", fontSize: 11 }}>✓</span>
            </div>
            <span style={{ color: "#D1D5DB", fontSize: 14 }}>{f}</span>
          </div>
        ))}
      </div>
    </div>
  );

  // MAIN APP
  return (
    <div style={{ minHeight: "100vh", background: "#F9FAFB", fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:translateY(0); } }
        .page { animation: fadeUp 0.35s ease; }
        .job-card:hover { border-color: #D1D5DB !important; box-shadow: 0 2px 12px rgba(0,0,0,0.07) !important; }
        .tab-item:hover { background: #F3F4F6 !important; }
        .save-btn:hover { background: #F3F4F6 !important; }
        .apply-btn:hover { background: #374151 !important; }
        input:focus, select:focus { border-color: #9CA3AF !important; outline: none; }
        ::-webkit-scrollbar { width: 4px; } ::-webkit-scrollbar-track { background: transparent; } ::-webkit-scrollbar-thumb { background: #E5E7EB; border-radius: 2px; }
      `}</style>

      {/* Sidebar */}
      <div style={{ position: "fixed", left: 0, top: 0, bottom: 0, width: 220, background: "#fff", borderRight: "1px solid #E5E7EB", display: "flex", flexDirection: "column", zIndex: 100 }}>
        <div style={{ padding: "24px 20px 16px", borderBottom: "1px solid #F3F4F6" }}>
          <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 20, color: "#111827", letterSpacing: "-0.5px" }}>HireFlow</div>
        </div>

        <div style={{ flex: 1, padding: "12px 10px" }}>
          {TABS.map(tab => (
            <button key={tab} className="tab-item" onClick={() => setActiveTab(tab)} style={{
              width: "100%", textAlign: "left", padding: "10px 12px", borderRadius: 8, border: "none", cursor: "pointer", fontSize: 14, fontFamily: "'DM Sans', sans-serif",
              background: activeTab === tab ? "#F3F4F6" : "transparent",
              color: activeTab === tab ? "#111827" : "#6B7280",
              fontWeight: activeTab === tab ? 500 : 400,
              marginBottom: 2, transition: "background 0.15s"
            }}>
              {tab === "Dashboard" && "⊞ "}{tab === "Find Jobs" && "⊕ "}{tab === "My Applications" && "☐ "}{tab === "Profile" && "◯ "}
              {tab}
              {tab === "My Applications" && <span style={{ marginLeft: "auto", float: "right", background: "#F3F4F6", borderRadius: 10, padding: "1px 7px", fontSize: 11, color: "#6B7280" }}>{applications.length}</span>}
            </button>
          ))}
        </div>

        <div style={{ padding: "16px 10px", borderTop: "1px solid #F3F4F6" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px" }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: "#111827", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 13, fontWeight: 600, flexShrink: 0 }}>
              {profile?.name?.charAt(0) || "U"}
            </div>
            <div style={{ overflow: "hidden" }}>
              <div style={{ fontSize: 13, fontWeight: 500, color: "#111827", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{profile?.name || "User"}</div>
              <div style={{ fontSize: 11, color: "#9CA3AF", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{profile?.email || ""}</div>
            </div>
          </div>
          <button onClick={() => setScreen("landing")} style={{ width: "100%", marginTop: 4, padding: "8px 12px", borderRadius: 8, border: "none", background: "transparent", cursor: "pointer", fontSize: 13, color: "#9CA3AF", textAlign: "left", fontFamily: "'DM Sans', sans-serif" }}>← Sign out</button>
        </div>
      </div>

      {/* Main */}
      <div style={{ marginLeft: 220, minHeight: "100vh" }}>

        {/* DASHBOARD */}
        {activeTab === "Dashboard" && (
          <div className="page" style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: 0, minHeight: "100vh" }}>
            <div style={{ padding: 36, borderRight: "1px solid #E5E7EB", overflowY: "auto" }}>
              <div style={{ marginBottom: 32 }}>
                <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 28, color: "#111827", letterSpacing: "-0.5px", marginBottom: 4 }}>
                  Good morning{profile?.name ? `, ${profile.name.split(" ")[0]}` : ""}. 👋
                </h1>
                <p style={{ color: "#9CA3AF", fontSize: 14 }}>{cvParsed ? "Your CV is parsed. Here's your job search overview." : "Upload your CV to get personalized job matches."}</p>
              </div>

              {/* Stats */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 32 }}>
                {[
                  { label: "Jobs matched", value: filteredJobs.length, sub: "based on your profile" },
                  { label: "Applications", value: applications.length, sub: `${applications.filter(a => a.status === "Interview").length} in interview` },
                  { label: "Profile score", value: cvParsed ? "92%" : "40%", sub: cvParsed ? "Strong profile" : "Upload CV to improve" }
                ].map((s, i) => (
                  <div key={i} style={{ background: "#fff", border: "1px solid #E5E7EB", borderRadius: 12, padding: "20px 20px" }}>
                    <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 28, color: "#111827", marginBottom: 4 }}>{s.value}</div>
                    <div style={{ fontSize: 12, color: "#6B7280" }}>{s.label}</div>
                    <div style={{ fontSize: 11, color: "#9CA3AF", marginTop: 2 }}>{s.sub}</div>
                  </div>
                ))}
              </div>

              {/* CV Upload */}
              <div style={{ background: "#fff", border: "1px solid #E5E7EB", borderRadius: 12, padding: 24, marginBottom: 24 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
                  <div style={{ fontWeight: 600, fontSize: 15, color: "#111827" }}>Your CV</div>
                  {cvParsed && <span style={{ fontSize: 12, color: "#22C55E", background: "#F0FDF4", padding: "3px 10px", borderRadius: 20 }}>✓ Parsed</span>}
                </div>
                {!cvFile ? (
                  <div onClick={() => fileRef.current.click()} style={{ border: "2px dashed #E5E7EB", borderRadius: 10, padding: "28px 20px", textAlign: "center", cursor: "pointer", background: "#FAFAFA", transition: "border-color 0.2s" }}
                    onMouseOver={e => e.currentTarget.style.borderColor = "#9CA3AF"}
                    onMouseOut={e => e.currentTarget.style.borderColor = "#E5E7EB"}>
                    <div style={{ fontSize: 28, marginBottom: 8 }}>📄</div>
                    <div style={{ fontSize: 14, color: "#374151", fontWeight: 500, marginBottom: 4 }}>Upload your CV</div>
                    <div style={{ fontSize: 12, color: "#9CA3AF" }}>PDF, DOCX, or TXT · Max 5MB</div>
                    <input ref={fileRef} type="file" accept=".pdf,.doc,.docx,.txt" style={{ display: "none" }} onChange={handleFileUpload} />
                  </div>
                ) : (
                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", background: "#F9FAFB", borderRadius: 10, marginBottom: 16 }}>
                      <span style={{ fontSize: 20 }}>📄</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 500, color: "#111827" }}>{cvFile.name}</div>
                        <div style={{ fontSize: 11, color: "#9CA3AF" }}>{(cvFile.size / 1024).toFixed(0)} KB</div>
                      </div>
                      {cvLoading ? <Spinner /> : <span style={{ color: "#22C55E", fontSize: 16 }}>✓</span>}
                    </div>
                    {cvParsed && (
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                        {cvParsed.skills?.map((s, i) => (
                          <span key={i} style={{ fontSize: 12, padding: "4px 10px", borderRadius: 20, background: "#F3F4F6", color: "#374151" }}>{s}</span>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Recent Applications */}
              <div style={{ background: "#fff", border: "1px solid #E5E7EB", borderRadius: 12, padding: 24 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
                  <div style={{ fontWeight: 600, fontSize: 15, color: "#111827" }}>Recent Applications</div>
                  <button onClick={() => setActiveTab("My Applications")} style={{ fontSize: 13, color: "#6B7280", background: "none", border: "none", cursor: "pointer" }}>View all →</button>
                </div>
                {applications.slice(0, 3).map(app => (
                  <div key={app.id} style={{ display: "flex", alignItems: "center", gap: 12, paddingBottom: 14, marginBottom: 14, borderBottom: "1px solid #F3F4F6" }}>
                    <div style={{ width: 36, height: 36, borderRadius: 8, background: app.color, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 13, fontWeight: 700, flexShrink: 0 }}>{app.logo}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13.5, fontWeight: 500, color: "#111827" }}>{app.title}</div>
                      <div style={{ fontSize: 12, color: "#9CA3AF" }}>{app.company} · {app.date}</div>
                    </div>
                    <span style={{ fontSize: 11.5, padding: "3px 10px", borderRadius: 20, fontWeight: 500, background: STATUS_COLORS[app.status]?.bg, color: STATUS_COLORS[app.status]?.text, whiteSpace: "nowrap" }}>{app.status}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Chat */}
            <div style={{ padding: 24, background: "#FAFAFA", height: "100vh", position: "sticky", top: 0, overflow: "hidden" }}>
              <AIChat cvParsed={cvParsed} profile={profile} />
            </div>
          </div>
        )}

        {/* FIND JOBS */}
        {activeTab === "Find Jobs" && (
          <div className="page" style={{ display: "grid", gridTemplateColumns: "1fr 340px", minHeight: "100vh" }}>
            <div style={{ padding: 36, overflowY: "auto", borderRight: "1px solid #E5E7EB" }}>
              <div style={{ marginBottom: 24 }}>
                <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 26, color: "#111827", marginBottom: 16, letterSpacing: "-0.5px" }}>Find Jobs</h1>
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by title, company, or skill…" style={{ width: "100%", padding: "11px 16px", border: "1px solid #E5E7EB", borderRadius: 10, fontSize: 14, color: "#111827", background: "#fff", marginBottom: 12, transition: "border-color 0.2s" }} />
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <select value={jobType} onChange={e => setJobType(e.target.value)} style={{ padding: "8px 12px", border: "1px solid #E5E7EB", borderRadius: 8, fontSize: 13, background: "#fff", color: "#374151" }}>
                    {JOB_TYPES.map(t => <option key={t}>{t}</option>)}
                  </select>
                  <select value={jobCategory} onChange={e => setJobCategory(e.target.value)} style={{ padding: "8px 12px", border: "1px solid #E5E7EB", borderRadius: 8, fontSize: 13, background: "#fff", color: "#374151" }}>
                    {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                  </select>
                  <select value={jobExp} onChange={e => setJobExp(e.target.value)} style={{ padding: "8px 12px", border: "1px solid #E5E7EB", borderRadius: 8, fontSize: 13, background: "#fff", color: "#374151" }}>
                    {EXPERIENCE.map(e => <option key={e}>{e}</option>)}
                  </select>
                </div>
              </div>

              <div style={{ fontSize: 13, color: "#9CA3AF", marginBottom: 16 }}>{filteredJobs.length} roles found</div>

              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {filteredJobs.map(job => (
                  <div key={job.id} className="job-card" style={{ background: "#fff", border: "1px solid #E5E7EB", borderRadius: 12, padding: 20, transition: "all 0.2s", cursor: "pointer" }}>
                    <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
                      <div style={{ width: 42, height: 42, borderRadius: 10, background: job.color, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 15, fontWeight: 700, flexShrink: 0 }}>{job.logo}</div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8, marginBottom: 2 }}>
                          <div style={{ fontSize: 15, fontWeight: 600, color: "#111827" }}>{job.title}</div>
                          <div style={{ display: "flex", alignItems: "center", gap: 6, flexShrink: 0 }}>
                            <div style={{ fontSize: 12, color: job.match >= 90 ? "#15803D" : job.match >= 80 ? "#C2410C" : "#6B7280", background: job.match >= 90 ? "#F0FDF4" : job.match >= 80 ? "#FFF7ED" : "#F9FAFB", padding: "2px 8px", borderRadius: 20, fontWeight: 500 }}>{job.match}% match</div>
                          </div>
                        </div>
                        <div style={{ fontSize: 13, color: "#6B7280", marginBottom: 8 }}>{job.company} · {job.location} · {job.salary}</div>
                        <div style={{ fontSize: 13, color: "#4B5563", lineHeight: 1.5, marginBottom: 12 }}>{job.description}</div>
                        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                            {job.tags.map(t => <span key={t} style={{ fontSize: 11.5, padding: "3px 9px", borderRadius: 20, background: "#F3F4F6", color: "#374151" }}>{t}</span>)}
                            <span style={{ fontSize: 11.5, padding: "3px 9px", borderRadius: 20, background: "#EEF2FF", color: "#4338CA" }}>{job.type}</span>
                          </div>
                          <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
                            <button className="save-btn" onClick={() => setSavedJobs(prev => prev.includes(job.id) ? prev.filter(id => id !== job.id) : [...prev, job.id])} style={{ padding: "7px 12px", borderRadius: 8, border: "1px solid #E5E7EB", background: "#fff", cursor: "pointer", fontSize: 13, color: savedJobs.includes(job.id) ? "#111827" : "#9CA3AF", transition: "background 0.15s" }}>
                              {savedJobs.includes(job.id) ? "♥" : "♡"}
                            </button>
                            <button className="apply-btn" onClick={() => !appliedNow.includes(job.id) && handleApply(job)} style={{ padding: "7px 16px", borderRadius: 8, border: "none", background: appliedNow.includes(job.id) ? "#F3F4F6" : "#111827", color: appliedNow.includes(job.id) ? "#9CA3AF" : "#fff", cursor: appliedNow.includes(job.id) ? "default" : "pointer", fontSize: 13, fontWeight: 500, transition: "background 0.15s" }}>
                              {appliedNow.includes(job.id) ? "Applied ✓" : "Apply"}
                            </button>
                          </div>
                        </div>
                        <div style={{ fontSize: 11, color: "#9CA3AF", marginTop: 10 }}>Posted {job.posted}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ padding: 24, background: "#FAFAFA", height: "100vh", position: "sticky", top: 0, overflow: "hidden" }}>
              <AIChat cvParsed={cvParsed} profile={profile} />
            </div>
          </div>
        )}

        {/* MY APPLICATIONS */}
        {activeTab === "My Applications" && (
          <div className="page" style={{ padding: 36, maxWidth: 900 }}>
            <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 26, color: "#111827", marginBottom: 8, letterSpacing: "-0.5px" }}>My Applications</h1>
            <p style={{ color: "#9CA3AF", fontSize: 14, marginBottom: 28 }}>Track the status of every role you've applied to.</p>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 32 }}>
              {[["Applied", "#EEF2FF", "#4338CA"], ["Reviewing", "#FFF7ED", "#C2410C"], ["Interview", "#F0FDF4", "#15803D"], ["Rejected", "#FEF2F2", "#B91C1C"]].map(([status, bg, color]) => (
                <div key={status} style={{ background: bg, borderRadius: 12, padding: "16px 20px" }}>
                  <div style={{ fontSize: 22, fontFamily: "'DM Serif Display', serif", color, marginBottom: 4 }}>{applications.filter(a => a.status === status).length}</div>
                  <div style={{ fontSize: 13, color, opacity: 0.8 }}>{status}</div>
                </div>
              ))}
            </div>

            <div style={{ background: "#fff", border: "1px solid #E5E7EB", borderRadius: 12, overflow: "hidden" }}>
              <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 2fr", padding: "12px 20px", borderBottom: "1px solid #F3F4F6", fontSize: 12, color: "#9CA3AF", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                <div>Role</div><div>Status</div><div>Applied</div><div>Next step</div>
              </div>
              {applications.map((app, i) => (
                <div key={app.id} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 2fr", padding: "16px 20px", borderBottom: i < applications.length - 1 ? "1px solid #F9FAFB" : "none", alignItems: "center" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 36, height: 36, borderRadius: 8, background: app.color, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 13, fontWeight: 700, flexShrink: 0 }}>{app.logo}</div>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 500, color: "#111827" }}>{app.title}</div>
                      <div style={{ fontSize: 12, color: "#9CA3AF" }}>{app.company}</div>
                    </div>
                  </div>
                  <div><span style={{ fontSize: 12, padding: "4px 10px", borderRadius: 20, fontWeight: 500, background: STATUS_COLORS[app.status]?.bg, color: STATUS_COLORS[app.status]?.text }}>{app.status}</span></div>
                  <div style={{ fontSize: 13, color: "#6B7280" }}>{app.date}</div>
                  <div style={{ fontSize: 13, color: "#6B7280" }}>{app.next}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* PROFILE */}
        {activeTab === "Profile" && (
          <div className="page" style={{ padding: 36, maxWidth: 700 }}>
            <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 26, color: "#111827", marginBottom: 28, letterSpacing: "-0.5px" }}>Profile</h1>

            <div style={{ background: "#fff", border: "1px solid #E5E7EB", borderRadius: 12, padding: 28, marginBottom: 20 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 24 }}>
                <div style={{ width: 56, height: 56, borderRadius: "50%", background: "#111827", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 20, fontWeight: 600 }}>{profile?.name?.charAt(0) || "U"}</div>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 600, color: "#111827" }}>{profile?.name || "—"}</div>
                  <div style={{ fontSize: 13, color: "#9CA3AF" }}>{profile?.email || "—"}</div>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                {[["Role", profile?.role || "—"], ["Experience", profile?.experience || "—"]].map(([label, val]) => (
                  <div key={label}>
                    <div style={{ fontSize: 12, color: "#9CA3AF", marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.05em" }}>{label}</div>
                    <div style={{ fontSize: 14, color: "#374151" }}>{val}</div>
                  </div>
                ))}
              </div>
            </div>

            {cvParsed && (
              <div style={{ background: "#fff", border: "1px solid #E5E7EB", borderRadius: 12, padding: 28, marginBottom: 20 }}>
                <div style={{ fontWeight: 600, fontSize: 15, color: "#111827", marginBottom: 16 }}>CV Insights</div>
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 12, color: "#9CA3AF", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" }}>Top Skills</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {cvParsed.skills?.map((s, i) => <span key={i} style={{ fontSize: 13, padding: "5px 12px", borderRadius: 20, background: "#F3F4F6", color: "#374151" }}>{s}</span>)}
                  </div>
                </div>
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 12, color: "#9CA3AF", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" }}>Top Strengths</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {cvParsed.topStrengths?.map((s, i) => (
                      <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13.5, color: "#374151" }}>
                        <span style={{ color: "#22C55E" }}>✓</span> {s}
                      </div>
                    ))}
                  </div>
                </div>
                {cvParsed.summary && <div style={{ fontSize: 13.5, color: "#6B7280", lineHeight: 1.6, padding: "14px 16px", background: "#F9FAFB", borderRadius: 8 }}>{cvParsed.summary}</div>}
              </div>
            )}

            {!cvFile && (
              <div style={{ background: "#fff", border: "1px dashed #E5E7EB", borderRadius: 12, padding: 28, textAlign: "center" }}>
                <div style={{ fontSize: 24, marginBottom: 8 }}>📄</div>
                <div style={{ fontSize: 14, color: "#374151", fontWeight: 500, marginBottom: 4 }}>No CV uploaded yet</div>
                <div style={{ fontSize: 13, color: "#9CA3AF", marginBottom: 16 }}>Upload your CV from the Dashboard for AI-powered matching</div>
                <button onClick={() => setActiveTab("Dashboard")} style={{ padding: "9px 20px", borderRadius: 8, border: "1px solid #E5E7EB", background: "#fff", cursor: "pointer", fontSize: 13.5, color: "#374151" }}>Go to Dashboard →</button>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
