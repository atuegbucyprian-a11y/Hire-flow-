-- ============================================================
-- HireFlow — Supabase Database Schema
-- Run this entire file in your Supabase SQL Editor
-- https://supabase.com/dashboard → SQL Editor → New Query
-- ============================================================

-- ─────────────────────────────────────────────
-- 1. PROFILES TABLE
-- Stores public user profile and parsed CV data
-- ─────────────────────────────────────────────
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  full_name     text,
  email         text,
  job_title     text,
  experience_level text,
  cv_file_path  text,        -- path in Supabase Storage bucket 'cvs'
  cv_parsed     jsonb,       -- structured data extracted by Claude
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- Auto-create a profile row when a new user signs up
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name'
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ─────────────────────────────────────────────
-- 2. APPLICATIONS TABLE
-- Stores job applications per user
-- ─────────────────────────────────────────────
create table if not exists public.applications (
  id            bigserial primary key,
  user_id       uuid not null references auth.users(id) on delete cascade,
  job_id        integer,
  job_title     text not null,
  company       text not null,
  job_type      text,
  salary        text,
  location      text,
  status        text not null default 'Applied'
                  check (status in ('Applied','Reviewing','Interview','Offer','Rejected')),
  notes         text,
  applied_at    timestamptz default now(),
  updated_at    timestamptz default now(),
  created_at    timestamptz default now()
);

-- ─────────────────────────────────────────────
-- 3. ROW LEVEL SECURITY (RLS)
-- This is the critical data isolation layer.
-- Even if someone gets a valid JWT, they can
-- only read/write their OWN rows.
-- ─────────────────────────────────────────────

-- Enable RLS on both tables
alter table public.profiles enable row level security;
alter table public.applications enable row level security;

-- Profiles: users can only see and edit their own profile
create policy "Users can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Applications: users can only access their own applications
create policy "Users can view own applications"
  on public.applications for select
  using (auth.uid() = user_id);

create policy "Users can insert own applications"
  on public.applications for insert
  with check (auth.uid() = user_id);

create policy "Users can update own applications"
  on public.applications for update
  using (auth.uid() = user_id);

create policy "Users can delete own applications"
  on public.applications for delete
  using (auth.uid() = user_id);

-- ─────────────────────────────────────────────
-- 4. STORAGE BUCKET FOR CVs
-- Run this separately in Supabase Storage settings
-- or uncomment if your Supabase version supports it
-- ─────────────────────────────────────────────

-- insert into storage.buckets (id, name, public)
-- values ('cvs', 'cvs', false);  -- private bucket

-- Storage RLS: users can only access their own folder
-- create policy "Users can upload own CV"
--   on storage.objects for insert
--   with check (bucket_id = 'cvs' and auth.uid()::text = (storage.foldername(name))[1]);

-- create policy "Users can read own CV"
--   on storage.objects for select
--   using (bucket_id = 'cvs' and auth.uid()::text = (storage.foldername(name))[1]);

-- create policy "Users can delete own CV"
--   on storage.objects for delete
--   using (bucket_id = 'cvs' and auth.uid()::text = (storage.foldername(name))[1]);

-- ─────────────────────────────────────────────
-- Done! Your database is secured.
-- ─────────────────────────────────────────────
