import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { requireAuth, parseBody } from '@/lib/auth'
import { createAdminSupabaseClient } from '@/lib/supabase/server'

const ApplicationSchema = z.object({
  job_id: z.number(),
  job_title: z.string().max(200),
  company: z.string().max(200),
  job_type: z.string().max(50),
  salary: z.string().max(100).optional(),
  location: z.string().max(200).optional(),
})

// GET — fetch the authenticated user's applications only
export async function GET(request: NextRequest) {
  try {
    const { user } = await requireAuth(request)
    const supabase = createAdminSupabaseClient()

    // user_id = auth.uid() is enforced by Row Level Security in Supabase
    // even if someone bypasses this route, RLS blocks cross-user reads
    const { data, error } = await supabase
      .from('applications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })

    if (error) throw error

    return NextResponse.json({ applications: data })

  } catch (err: any) {
    if (err instanceof NextResponse) return err
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST — create a new application for the authenticated user
export async function POST(request: NextRequest) {
  try {
    const { user } = await requireAuth(request)
    const body = await parseBody<z.infer<typeof ApplicationSchema>>(request, ApplicationSchema)
    const supabase = createAdminSupabaseClient()

    const { data, error } = await supabase
      .from('applications')
      .insert({
        user_id: user.id, // always set server-side, never trusted from client
        ...body,
        status: 'Applied',
        applied_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ application: data }, { status: 201 })

  } catch (err: any) {
    if (err instanceof NextResponse) return err
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// PATCH — update application status
export async function PATCH(request: NextRequest) {
  try {
    const { user } = await requireAuth(request)
    const { id, status } = await request.json()

    const validStatuses = ['Applied', 'Reviewing', 'Interview', 'Offer', 'Rejected']
    if (!validStatuses.includes(status)) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 })
    }

    const supabase = createAdminSupabaseClient()

    // The .eq('user_id', user.id) ensures users can only update their own records
    const { error } = await supabase
      .from('applications')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id)
      .eq('user_id', user.id) // ownership check

    if (error) throw error

    return NextResponse.json({ success: true })

  } catch (err: any) {
    if (err instanceof NextResponse) return err
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
