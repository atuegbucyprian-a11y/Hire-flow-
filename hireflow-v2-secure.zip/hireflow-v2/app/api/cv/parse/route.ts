import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { requireAuth } from '@/lib/auth'
import { createAdminSupabaseClient } from '@/lib/supabase/server'

// Anthropic client — instantiated server-side only
// The API key is NEVER sent to the browser
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

export async function POST(request: NextRequest) {
  try {
    // 1. Verify the user is authenticated
    const { user } = await requireAuth(request)

    // 2. Parse the uploaded file
    const formData = await request.formData()
    const file = formData.get('cv') as File | null

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    // Enforce file size limit (5MB)
    if (file.size > 5 * 1024 * 1024) {
      return NextResponse.json({ error: 'File too large. Max 5MB.' }, { status: 400 })
    }

    // Enforce file type
    const allowed = ['application/pdf', 'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain']
    if (!allowed.includes(file.type)) {
      return NextResponse.json({ error: 'Invalid file type. Use PDF, DOCX, or TXT.' }, { status: 400 })
    }

    // 3. Store the raw CV in Supabase Storage under the user's own folder
    // Row Level Security ensures users can only access files in their own folder
    const adminSupabase = createAdminSupabaseClient()
    const fileName = `${user.id}/cv-${Date.now()}.${file.name.split('.').pop()}`
    const fileBuffer = Buffer.from(await file.arrayBuffer())

    const { error: storageError } = await adminSupabase.storage
      .from('cvs')
      .upload(fileName, fileBuffer, {
        contentType: file.type,
        upsert: true,
      })

    if (storageError) {
      console.error('Storage error:', storageError)
      return NextResponse.json({ error: 'Failed to store CV' }, { status: 500 })
    }

    // 4. Extract text content for AI parsing
    const cvText = await file.text()

    // 5. Parse CV with Claude — runs entirely server-side
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      system: `You are a CV parser. Extract structured information from the CV and return ONLY valid JSON with no markdown, no explanation.
Return this exact shape:
{
  "name": "string",
  "title": "string",
  "email": "string or null",
  "skills": ["up to 10 skills"],
  "experience_years": number,
  "top_strengths": ["3 short strengths"],
  "summary": "1 sentence professional summary",
  "education": "highest qualification or null",
  "languages": ["languages spoken"]
}`,
      messages: [{ role: 'user', content: `Parse this CV:\n\n${cvText.slice(0, 4000)}` }],
    })

    const rawText = message.content
      .filter(b => b.type === 'text')
      .map(b => (b as any).text)
      .join('')

    let parsed: any
    try {
      parsed = JSON.parse(rawText.replace(/```json|```/g, '').trim())
    } catch {
      parsed = {
        name: null,
        title: 'Professional',
        skills: [],
        experience_years: 0,
        top_strengths: [],
        summary: 'Experienced professional.',
        education: null,
        languages: [],
      }
    }

    // 6. Save parsed data to the user's profile in the database
    const { error: dbError } = await adminSupabase
      .from('profiles')
      .upsert({
        id: user.id,
        cv_file_path: fileName,
        cv_parsed: parsed,
        updated_at: new Date().toISOString(),
      })

    if (dbError) {
      console.error('DB error:', dbError)
    }

    // 7. Return parsed data to the client — never the raw file or API key
    return NextResponse.json({ success: true, parsed })

  } catch (err: any) {
    // If requireAuth threw a NextResponse, re-throw it
    if (err instanceof NextResponse) return err
    console.error('CV parse error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
