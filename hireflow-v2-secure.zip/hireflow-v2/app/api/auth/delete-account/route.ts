import { NextRequest, NextResponse } from 'next/server'
import { requireAuth } from '@/lib/auth'
import { createAdminSupabaseClient } from '@/lib/supabase/server'

// DELETE — permanently removes all user data (GDPR right to erasure)
export async function DELETE(request: NextRequest) {
  try {
    const { user } = await requireAuth(request)
    const adminSupabase = createAdminSupabaseClient()

    // 1. Delete CV files from storage
    const { data: files } = await adminSupabase.storage
      .from('cvs')
      .list(user.id)

    if (files && files.length > 0) {
      const paths = files.map(f => `${user.id}/${f.name}`)
      await adminSupabase.storage.from('cvs').remove(paths)
    }

    // 2. Delete all user data from tables
    await adminSupabase.from('applications').delete().eq('user_id', user.id)
    await adminSupabase.from('profiles').delete().eq('id', user.id)

    // 3. Delete the auth user account
    await adminSupabase.auth.admin.deleteUser(user.id)

    return NextResponse.json({ success: true, message: 'Account and all data deleted.' })

  } catch (err: any) {
    if (err instanceof NextResponse) return err
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
