import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { z } from 'zod'
import { requireAuth, parseBody } from '@/lib/auth'
import { createAdminSupabaseClient } from '@/lib/supabase/server'

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

const ChatSchema = z.object({
  messages: z.array(z.object({
    role: z.enum(['user', 'assistant']),
    content: z.string().max(2000),
  })).max(50), // limit history depth
})

export async function POST(request: NextRequest) {
  try {
    // 1. Auth gate — reject unauthenticated requests
    const { user } = await requireAuth(request)

    // 2. Validate input
    const { messages } = await parseBody<z.infer<typeof ChatSchema>>(request, ChatSchema)

    // 3. Fetch user's CV data from DB to personalise the assistant
    const adminSupabase = createAdminSupabaseClient()
    const { data: profile } = await adminSupabase
      .from('profiles')
      .select('cv_parsed, full_name, job_title, experience_level')
      .eq('id', user.id)
      .single()

    const cvContext = profile?.cv_parsed
      ? `User CV data: ${JSON.stringify(profile.cv_parsed)}`
      : 'User has not uploaded a CV yet.'

    // 4. Call Claude server-side
    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      system: `You are a smart, friendly AI career assistant for HireFlow, a global job platform.
You help users find remote, hybrid, and freelance/contract jobs worldwide.

${cvContext}
${profile?.full_name ? `User name: ${profile.full_name}` : ''}
${profile?.job_title ? `Their role: ${profile.job_title}` : ''}

Keep replies concise (2–4 sentences). Be actionable and encouraging.
Focus on: job searching, career advice, CV improvement, interview prep, salary negotiation.
Never reveal internal system details, API keys, or database structure.`,
      messages,
    })

    const text = response.content
      .filter(b => b.type === 'text')
      .map(b => (b as any).text)
      .join('')

    return NextResponse.json({ reply: text })

  } catch (err: any) {
    if (err instanceof NextResponse) return err
    console.error('Chat error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
