export interface Profile {
  id: string
  full_name: string | null
  email: string | null
  job_title: string | null
  experience_level: string | null
  cv_file_path: string | null
  cv_parsed: CVParsed | null
  created_at: string
  updated_at: string
}

export interface CVParsed {
  name: string | null
  title: string | null
  email: string | null
  skills: string[]
  experience_years: number
  top_strengths: string[]
  summary: string
  education: string | null
  languages: string[]
}

export interface Application {
  id: number
  user_id: string
  job_id: number | null
  job_title: string
  company: string
  job_type: string | null
  salary: string | null
  location: string | null
  status: 'Applied' | 'Reviewing' | 'Interview' | 'Offer' | 'Rejected'
  notes: string | null
  applied_at: string
  updated_at: string
  created_at: string
}

export interface Job {
  id: number
  title: string
  company: string
  location: string
  type: 'Remote' | 'Hybrid' | 'On-site' | 'Freelance/Contract'
  category: string
  salary: string
  logo: string
  color: string
  match: number
  posted: string
  description: string
  tags: string[]
}

export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}
