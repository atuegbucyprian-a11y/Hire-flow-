import { createBrowserClient } from '@supabase/ssr'

// Browser client — only has access to the anon key (safe to expose)
// Row Level Security on Supabase ensures users can only see their own data
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
