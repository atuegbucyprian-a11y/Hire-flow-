import { createBrowserClient } from '@supabase/ssr'

// This client uses only the anon key — safe for the browser.
// Row Level Security (RLS) on Supabase tables enforces that users
// can only read/write their own data.
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
