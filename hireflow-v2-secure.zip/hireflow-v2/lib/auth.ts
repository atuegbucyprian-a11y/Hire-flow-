import { createServerSupabaseClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

/**
 * requireAuth — call at the top of every protected API route.
 * Returns the authenticated user or throws a 401.
 */
export async function requireAuth(request: NextRequest) {
  const supabase = createServerSupabaseClient()
  const { data: { user }, error } = await supabase.auth.getUser()

  if (error || !user) {
    throw NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  return { user, supabase }
}

/**
 * parseBody — validate + parse request JSON with a Zod schema.
 * Throws a 400 on failure.
 */
export async function parseBody<T>(request: NextRequest, schema: any): Promise<T> {
  try {
    const body = await request.json()
    return schema.parse(body)
  } catch (e: any) {
    throw NextResponse.json(
      { error: 'Invalid request', details: e.errors ?? e.message },
      { status: 400 }
    )
  }
}
