# HireFlow v2 — Secure Backend

AI-powered job hunting platform built with **Next.js 14 + Supabase + Claude**.  
All AI calls and database access happen **server-side only** — no secrets are ever exposed to the browser.

---

## 🔐 Security Architecture

```
Browser (React)
    │  HTTPS only — no API keys, no DB access
    ▼
Next.js API Routes  (/app/api/*)
    │  Auth validated on every request
    │  Input validated with Zod schemas
    │  ANTHROPIC_API_KEY lives here only
    ▼
Supabase (Auth + Database + Storage)
    │  Row Level Security (RLS) on all tables
    │  Users can only read/write their own rows
    │  CV files stored in private bucket per user
    ▼
Anthropic Claude API
    │  Called server-side only
    │  User data never sent beyond what's needed
```

### Why this is safe

| Threat | Protection |
|---|---|
| Stolen Anthropic API key | Key is server-only (`ANTHROPIC_API_KEY`, no `NEXT_PUBLIC_`) |
| Cross-user data access | Supabase Row Level Security (RLS) on every table |
| Unauthenticated API calls | `requireAuth()` middleware on all API routes |
| Invalid/malicious input | Zod schema validation on every POST body |
| CV file theft | Private storage bucket, files scoped to `user_id/` folder |
| Account data after deletion | Full cascade delete: files → rows → auth user |
| Session hijacking | Supabase SSR cookies, refreshed on every request |

---

## 🛠 Tech Stack

| Layer | Tech |
|---|---|
| Framework | Next.js 14 (App Router) |
| Auth | Supabase Auth (email/password + OAuth-ready) |
| Database | Supabase PostgreSQL with RLS |
| File Storage | Supabase Storage (private bucket) |
| AI | Anthropic Claude (`claude-sonnet-4-20250514`) |
| Validation | Zod |
| Language | TypeScript |

---

## 🚀 Setup

### 1. Clone

```bash
git clone https://github.com/YOUR_USERNAME/hireflow.git
cd hireflow
npm install
```

### 2. Create a Supabase project

Go to [supabase.com](https://supabase.com) → New Project.

Then run the schema in **SQL Editor → New Query**:

```bash
# Copy and paste the contents of supabase/schema.sql
```

Also create the **CV storage bucket**:
- Go to Storage → New bucket
- Name: `cvs`
- Make it **private** (uncheck "Public bucket")

### 3. Configure environment variables

```bash
cp .env.example .env.local
```

Fill in `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
ANTHROPIC_API_KEY=sk-ant-your-key
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

Find your Supabase keys at: **Project Settings → API**

### 4. Run

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 📁 Project Structure

```
hireflow-v2/
├── app/
│   ├── api/
│   │   ├── cv/parse/route.ts          # CV upload + Claude parsing
│   │   ├── chat/route.ts              # AI career assistant
│   │   ├── applications/route.ts      # CRUD for job applications
│   │   └── auth/delete-account/route.ts  # GDPR account deletion
│   ├── dashboard/                     # Protected dashboard pages
│   ├── login/                         # Auth pages
│   └── register/
├── lib/
│   ├── supabase/
│   │   ├── client.ts                  # Browser Supabase client (anon key)
│   │   └── server.ts                  # Server Supabase client (service role)
│   └── auth.ts                        # requireAuth() + parseBody() helpers
├── middleware.ts                       # Route protection + session refresh
├── types/index.ts                      # Shared TypeScript types
├── supabase/schema.sql                 # Database schema + RLS policies
└── .env.example
```

---

## 🔑 API Routes

All routes require a valid Supabase session cookie.

| Method | Route | Description |
|---|---|---|
| `POST` | `/api/cv/parse` | Upload CV, store in Supabase, parse with Claude |
| `POST` | `/api/chat` | Send message to AI career assistant |
| `GET` | `/api/applications` | Get user's applications |
| `POST` | `/api/applications` | Create new application |
| `PATCH` | `/api/applications` | Update application status |
| `DELETE` | `/api/auth/delete-account` | Delete account + all data (GDPR) |

---

## 🗺 Roadmap

- [ ] Connect a real job board API (Remotive, Adzuna)
- [ ] OAuth login (Google, LinkedIn)
- [ ] Email notifications for status changes
- [ ] Resume tailoring: rewrite CV per job description
- [ ] Rate limiting on API routes
- [ ] Admin dashboard for job posting

---

## 📄 License

MIT
